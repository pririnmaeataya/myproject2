<?php
//--test03.php
echo "Pruch Tareesak<hr>";
echo "business computer";

?>