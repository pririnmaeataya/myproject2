<?php
//--if01.php
$name="pruch";
if($name=="pruch")
	{
		echo "คุณป้อนชื่อคุณถูกต้อง";
	}

?>
