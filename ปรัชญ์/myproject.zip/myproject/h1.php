<?php
//--h1.php
echo "<img src = 'logo-bait.png' width='10%'>";
echo "<font color = 'blue' size ='+2'>BIT NEW)))</font><hr>";

?>