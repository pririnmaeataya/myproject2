<?php
//--variable2.php
$num1 =200;
$num2 =300;
$sum = $num1+$num2;
$a= 2.5;
$b = 2.5;
$c = $a+$b;

echo"$num1+$num2=".$sum."<br>";
echo"$a+$b=".$c;

?>