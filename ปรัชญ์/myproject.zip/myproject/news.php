<?php
//--news.php
include("h1.php");
include("body.php");
?>