<?php
//--constant.php
echo "การกำหนดค่าคงที่<HR>";
define("FULLNAME", "Pruch Tareesak");
define("ID", "459354121004");
define("NEW_LINE", "<br>");
define("INSTITUTE","Rajamangala University of Technology Suvarnnabhumi");
define("URL", "http://www.rmutsb.ac.th");

echo "สวัสดีคุณ  ".FULLNAME;
echo NEW_LINE;
echo "รหัสนักศึกษา  ".ID;
echo NEW_LINE;
echo "สถาบัน  ".INSTITUTE;
echo NEW_LINE;
echo "เว็บไซต์  ".URL;



?>

