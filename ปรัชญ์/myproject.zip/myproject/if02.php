<?php
//--if02.php
$username="pruch";
if($username=="popo")
	{
		echo "สวัสดีคุณ $username คุณคือตัวจริง";
	}else
	{
		echo "สวัสดีคุณ $username คุณคือตัวปลอม";
	}

?>
