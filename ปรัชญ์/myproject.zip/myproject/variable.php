<?php
//--variable.php
$fullname = "Pruch Tareesak<br>";
$id = "459354121004<br>";
$major = "business computer<br>";
$department = "business administration infomation technology";
$br = "<br>";
echo "ชื่อ-สกุล: " .$fullname.$br;
echo"รหัสนักศึกษา: " .$id.$br;
echo "สาขา: " .$major.$br;
echo"คณะ: " .$department;
?>