<?php
//--login.php

echo"ชื่อเรียก" .$_POST['username'];
echo "<br>";
echo "รหัสผ่าน" .$_POST['password'];

?>
