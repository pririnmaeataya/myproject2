<?php
//--test01.php
echo "Bank Hello World";
echo"<br>";
echo "i am Web Programmer";
?>