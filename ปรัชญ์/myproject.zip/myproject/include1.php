<?php
//--icclude1.php
$br="<br>";
echo "การดึงไฟล์อื่นมาร่วมกับ PHP<hr>";
include("test01.php");
echo $br;
include("variable.php");




?>