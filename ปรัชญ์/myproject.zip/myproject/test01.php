<?php
//--test01.php
echo "Pruch Hello world<br>";
echo "i am web programmer";
?>


