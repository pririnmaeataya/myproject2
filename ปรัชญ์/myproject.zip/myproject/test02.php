<?php
//--test02.php
phpinfo();
?>
